﻿using System.Collections.Generic;

namespace Northwind.Store.Notification
{
    public class Notifications : List<Message>
    {
    }
}
