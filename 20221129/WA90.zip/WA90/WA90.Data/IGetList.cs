﻿namespace WA90.Data
{
    public interface IGetList<T>
    {
        IEnumerable<T> GetList();
    }
}
